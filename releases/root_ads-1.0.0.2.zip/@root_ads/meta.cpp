name = "Root's Adaptive Detection System";
author = "Root";
overview = "Enemy AI progressively detect and recognize players concealed inside civilian or enemy vehicles.";

timestamp = 639269803380000000;
